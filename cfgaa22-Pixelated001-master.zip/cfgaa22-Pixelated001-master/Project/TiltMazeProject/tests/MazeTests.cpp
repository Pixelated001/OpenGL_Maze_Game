#include <gtest/gtest.h>
#include "Vec2.h"
#include "Board.h"
#include "Cell.h"

TEST(Vec2,ctor)
{
  Vec2 a;
  ASSERT_FLOAT_EQ(a.x,0.0f);
  ASSERT_FLOAT_EQ(a.y,0.0f);
}

TEST(Board, ctor)
{
  Board board(5,5);

  ASSERT_FLOAT_EQ(board.GetHeight(),5.0f);
  ASSERT_FLOAT_EQ(board.GetWidth(),5.0f);
  
  Vec2 Index(0,0);

  board.GetCell(Index)->Check();

  ASSERT_EQ(board.GetCell(Index)->GetChecked(),true);

  ASSERT_EQ(board.OppositeWall('N'),'S');

  Vec2 Index1(0,1);

  ASSERT_EQ(board.NextIndexCalc('N', Index).y, Index1.y);
  ASSERT_EQ(board.NextIndexCalc('N', Index).x, Index1.x);

  Board board1(5,5);

  Vec2 Index2(0,0);

  board.Generate(Index);

  ASSERT_EQ(board.GetCell(Index)->GetChecked(), true);
  ASSERT_NE(board.GetCell(Index)->GetDirection(0), 'N');

}

TEST(Cell, ctor)
{
  Cell cell;

  std::vector<char> Direction = {'N', 'E', 'S', 'W'};

  ASSERT_EQ(cell.GetDiretions(), Direction);


  cell.Remove('N');
  cell.Check();

  ASSERT_NE(cell.GetDirection(0), 'N');
  ASSERT_EQ(cell.GetChecked(), true);

  char first = cell.GetDirection(0);

  cell.Shuffle();

}