#ifndef NGLDRAW_H_
#define NGLDRAW_H_

#include <SDL2/SDL.h>
#include <ngl/Mat4.h>
#include <ngl/Vec3.h>
#include <ngl/Transformation.h>
#include "Sphere.h"
#include <ngl/BBox.h>
#include "Bounding.h"
//#include "Text.h"

class NGLDraw
{
  public :
    //----------------------------------------------------------------------------------------------------------------------
    /// @brief ctor this will have a valid OpenGL context so we can create gl stuff
    //----------------------------------------------------------------------------------------------------------------------
    NGLDraw();
    //----------------------------------------------------------------------------------------------------------------------
    /// @brief dtor used to remove any NGL stuff created
    //----------------------------------------------------------------------------------------------------------------------
    ~NGLDraw();
    //----------------------------------------------------------------------------------------------------------------------
    /// @brief resize our screen and set the camera aspect ratio
    /// @param[in] _w the new width
    /// @param[in] _h the new height
    //----------------------------------------------------------------------------------------------------------------------
    void resize( int _w, int _h );
    //----------------------------------------------------------------------------------------------------------------------
    /// @brief draw the scene
    //----------------------------------------------------------------------------------------------------------------------
    void draw();

    void drawStartScreen();
    //----------------------------------------------------------------------------------------------------------------------
    /// @brief this method is called every time a mouse button is presses
    /// @param _event the SDL mouse event structure containing all mouse info
    //----------------------------------------------------------------------------------------------------------------------
    int mousePressEvent (const SDL_MouseButtonEvent &_event);

    void AssignMaze(Board MazeInput);

    void RotateCameraPosX();

    void RotateCameraNegX();

    void RotateCameraPosZ();

    void RotateCameraNegZ();

    void MoveBall();

    bool BBoxCollision();

    int getmode() const {return m_mode;} 

    void setmode(int _mode) {m_mode = _mode;}

    void Restart();

    void CleanRestart();

    int getisPlayer1() const {return m_isPlayer1;}
    
    float getincrement() const {return m_increment;} 

    void setincrement(float _increment) {m_increment = _increment;} 

    void setisSwapPlayer(bool _isSwapPlayer) {m_isSwapPlayer = _isSwapPlayer;} 


  private :

    //----------------------------------------------------------------------------------------------------------------------
    /// @brief method to load transform data to the shaders
    //----------------------------------------------------------------------------------------------------------------------
    void loadMatricesToShader();
    //----------------------------------------------------------------------------------------------------------------------
    /// @brief used to store the x rotation mouse value
    //----------------------------------------------------------------------------------------------------------------------
    int m_spinXFace;
    //----------------------------------------------------------------------------------------------------------------------
    /// @brief used to store the y rotation mouse value
    //----------------------------------------------------------------------------------------------------------------------
    int m_spinYFace;

    int m_spinZFace;

    //----------------------------------------------------------------------------------------------------------------------
    /// @brief flag to indicate if the mouse button is pressed when dragging
    //----------------------------------------------------------------------------------------------------------------------
    bool m_rotate;
    //----------------------------------------------------------------------------------------------------------------------
    /// @brief flag to indicate if the Right mouse button is pressed when dragging
    //----------------------------------------------------------------------------------------------------------------------
    bool m_translate;
    //----------------------------------------------------------------------------------------------------------------------
    /// @brief the previous x mouse value
    //----------------------------------------------------------------------------------------------------------------------
    int m_origX;
    //----------------------------------------------------------------------------------------------------------------------
    /// @brief the previous y mouse value
    //----------------------------------------------------------------------------------------------------------------------
    int m_origY;
    //----------------------------------------------------------------------------------------------------------------------
    /// @brief the previous x mouse value for Position changes
    //----------------------------------------------------------------------------------------------------------------------
    int m_origXPos;
    //----------------------------------------------------------------------------------------------------------------------
    /// @brief the previous y mouse value for Position changes
    //----------------------------------------------------------------------------------------------------------------------
    int m_origYPos;
    //----------------------------------------------------------------------------------------------------------------------
    /// @brief used to store the global mouse transforms
    //----------------------------------------------------------------------------------------------------------------------
    ngl::Mat4 m_mouseGlobalTX;
    //----------------------------------------------------------------------------------------------------------------------
    /// @brief Our Camera
    //----------------------------------------------------------------------------------------------------------------------
    ngl::Mat4 m_view;
    ngl::Mat4 m_project;

    ngl::Transformation m_transform;
    //----------------------------------------------------------------------------------------------------------------------
    /// @brief the model position for mouse movement
    //----------------------------------------------------------------------------------------------------------------------
        
    std::vector< std::unique_ptr<Bounding> > m_buttons;
    std::vector< std::unique_ptr<Bounding> > m_sandBoxButtons;
    std::vector< std::unique_ptr<Bounding> > m_startScreenText;    
    std::vector< std::unique_ptr<Bounding> > m_twoPlayerText;

    std::unique_ptr<Bounding> m_backButton;
    std::unique_ptr<Bounding> m_scoreButton;
    std::unique_ptr<Bounding> m_player1Score;
    std::unique_ptr<Bounding> m_player2Score;
        
        
    bool m_isSwapPlayer = true;
    bool m_isPlayer1 = true;


    float m_increment = 1.01f;
    float m_ballMovementX;
    float m_ballMovementZ;
    float m_ballLocationX;
    float m_ballLocationZ;

    int m_mode = 0;
    int m_loop = 0;
    int m_score = 0;
    int m_score2 = 0;
    int m_width;
    int m_height;
    int m_mazeWidth;
    int m_mazeHeight;
    int m_numberOfPlayers = 1;


    void TextRendering(const char *_words, SDL_Color _color);
    void CollisionCheck();
    bool SphereCollision();

    std::vector<GLuint> m_textures;
    GLuint m_textureID;

    std::vector< std::unique_ptr<ngl::BBox> > m_boundingBoxs;

    std::vector <std::unique_ptr<Sphere>> m_sphereArray;
    
    ngl::Vec3 m_modelPos;

    Board m_maze;

};


#endif
