#ifndef VEC2_H_
#define VEC2_H_
struct Vec2
{
    Vec2()=default;
    Vec2( float _x, float _y );
    float m_x=0.0f;
    float m_y=0.0f;
};

#endif