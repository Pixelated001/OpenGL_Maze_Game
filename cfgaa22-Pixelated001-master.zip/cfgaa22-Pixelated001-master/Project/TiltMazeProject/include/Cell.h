#ifndef CELL_H_
#define CELL_H_
#include <vector>
#include <iostream>
class Cell
{
    public:
        char GetDirection(int _index) const;
        void Check();
        bool GetChecked() const;
        void Remove(const char _border); 
        void Shuffle();
        std::vector<char> GetDiretions() const;

    private: 
        std::vector<char> m_direction = {'N', 'E', 'S', 'W'}; 
        bool m_isChecked = false;
};

#endif