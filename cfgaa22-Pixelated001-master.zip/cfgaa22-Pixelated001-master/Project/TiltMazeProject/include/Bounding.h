#ifndef BOUNDING_H_
#define BOUNDING_H_

#include <ngl/Vec3.h>
#include <SDL2/SDL.h>


class Bounding
{
    public :

        Bounding(ngl::Vec3 _Center, float _Width, float _Height, float _Depth);
        void draw() const;        
        float getMinX() const {return m_MinX;}
        float getMinY() const {return m_MinY;}
        float getMinZ() const {return m_MinZ;}
        float getMaxX() const {return m_MaxX;}
        float getMaxY() const {return m_MaxY;}
        float getMaxZ() const {return m_MaxZ;}        
        std::string getText() const {return m_Text;}
        void setText(std::string _Text) {m_Text = _Text;}
        SDL_Color getColour() const {return m_colour;}        
        void setColour(SDL_Color _colour) {m_colour = _colour;}
        void setRotation(float _rot) {m_Rotation = _rot;}

    private :

        ngl::Vec3 m_Center;
        float m_Width;
        float m_Height;
        float m_Depth;
        float m_MinX;
        float m_MinY;
        float m_MinZ;
        float m_MaxX;
        float m_MaxY;
        float m_MaxZ;
        std::string m_Text;
        SDL_Color m_colour;
        float m_Rotation;
};

#endif
