#ifndef BOARD_H_
#define BOARD_H_
#include "Vec2.h"
#include "Cell.h"
#include <iostream>
#include <vector>
#include <ngl/BBox.h>
#include <ngl/Transformation.h>

struct Board
{
    public :

        Board()=default;
        Board( float _width, float _height );
        Cell* GetCell( const Vec2 _index );
        char OppositeWall( const char _wall ) const;
        Vec2 NextIndexCalc( char _border, Vec2 io_index );
        void Generate( Vec2 _index );
        void DrawMaze( const std::string &_shaderName, const ngl::Mat4 &_globalMat,  const ngl::Mat4 &_view , const ngl::Mat4 &_project );
        float GetWidth() const; 
        float GetHeight() const;
        std::vector< std::vector< Cell > > getMazeSize() const {return m_cells;}
    
    private :
        Vec2 m_dimensions = {0.0f, 0.0f};
        std::vector< std::vector< Cell > > m_cells;
        ngl::Transformation m_transform;
};

#endif