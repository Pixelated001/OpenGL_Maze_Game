#include <iostream>
#include "Board.h" 
#include "NGLDraw.h"
#include <ngl/ShaderLib.h>
#include <ngl/NGLInit.h>
#include <ngl/Transformation.h>
#include <algorithm>
#include <ngl/Texture.h>
#include <SDL2/SDL_ttf.h>


const static float INCREMENT=0.01f;
const static float ZOOM=0.05f;
constexpr auto PBR="PBR";
constexpr auto SS="SS";


NGLDraw::NGLDraw()
{ 

  if ( TTF_Init() < 0 ) 
  {

	  std::cout << "Error initializing SDL_ttf: " << TTF_GetError();

  }

  // Image Textures for the Start Screen m_buttons

  ngl::Texture tex1( "textures/Mag.png" );
  tex1.setMultiTexture( 0 );
  m_textures.push_back( tex1.setTextureGL() );

  ngl::Texture tex( "textures/Cast.png" );
  tex.setMultiTexture( 0 );
  m_textures.push_back( tex.setTextureGL() );

  ngl::Texture tex2( "textures/V2.png" );
  tex2.setMultiTexture( 0 );
  m_textures.push_back( tex2.setTextureGL() );

  //StartScreen buttons

  m_buttons.push_back( std::make_unique< Bounding > ( ngl::Vec3( 0.0f,0.0f,0.0f ) , 0.2f, 0.4f, 0.1f ) ); 
  m_buttons.back()->setRotation( 180.0f );

  m_buttons.push_back( std::make_unique< Bounding > ( ngl::Vec3( 0.6f,0.0f,0.0f ) , 0.2f, 0.4f, 0.1f ) ); 
  m_buttons.back()->setRotation( 180.0f );  

  m_buttons.push_back( std::make_unique< Bounding > ( ngl::Vec3( -0.6f,0.0f,0.0f ) , 0.2f, 0.4f, 0.1f ) ); 
  m_buttons.back()->setRotation( 180.0f );

  //StartScreen Text

  m_startScreenText.push_back( std::make_unique< Bounding > ( ngl::Vec3( 0.0f,-0.7f,0.0f ) , 0.2f, 0.13f, 0.1f ) );
  m_startScreenText.back()->setText( "Explore" );

  m_startScreenText.push_back( std::make_unique< Bounding > ( ngl::Vec3( 0.6f,-0.7f,0.0f ) , 0.27f, 0.13f, 0.1f ) );
  m_startScreenText.back()->setText( "SandBox" );

  m_startScreenText.push_back( std::make_unique< Bounding > ( ngl::Vec3( -0.6f,-0.7f,0.0f ) , 0.3f, 0.13f, 0.1f ) );
  m_startScreenText.back()->setText( "Two Player" );

  m_startScreenText.push_back( std::make_unique< Bounding > ( ngl::Vec3( 0.0f,0.75f,0.0f ) , 0.7f, 0.25f, 0.1f ) );
  m_startScreenText.back()->setText( "TILTMAZE GAME" );

  //SandBox buttons with text

  m_sandBoxButtons.push_back( std::make_unique< Bounding > ( ngl::Vec3( -0.3f,0.875f,0.0f ) ,0.04f, 0.15f, 0.1f ) ); 
  m_sandBoxButtons.back()->setText( "+" );

  m_sandBoxButtons.push_back( std::make_unique< Bounding > ( ngl::Vec3( -0.7f,0.875f,0.0f ) , 0.045f, 0.165f, 0.1f ) ); 
  m_sandBoxButtons.back()->setText( "-" );

  m_sandBoxButtons.push_back( std::make_unique< Bounding > ( ngl::Vec3( 0.2f,0.875f,0.0f ) , 0.045f, 0.165f, 0.1f ) ); 
  m_sandBoxButtons.back()->setText( "-" );

  m_sandBoxButtons.push_back( std::make_unique< Bounding > ( ngl::Vec3( 0.8f,0.875f,0.0f ) , 0.04f, 0.15f, 0.1f ) ); 
  m_sandBoxButtons.back()->setText( "+" );

  m_sandBoxButtons.push_back( std::make_unique< Bounding > ( ngl::Vec3( 0.5f,0.875f,0.0f ) , 0.2f, 0.1f, 0.1f ) ); 
  m_sandBoxButtons.back()->setText( "Enemies" );

  m_sandBoxButtons.push_back( std::make_unique< Bounding > ( ngl::Vec3( -0.5f,0.875f,0.0f ) , 0.1f, 0.1f, 0.1f ) ); 
  m_sandBoxButtons.back()->setText( "Size" );

  //TwoPlayer Text

  m_twoPlayerText.push_back(std::make_unique<Bounding>(ngl::Vec3( -0.75f,0.875f,0.0f ) , 0.2f, 0.125f, 0.1f ) ); 
  m_twoPlayerText.back()->setText("Player1");

  m_twoPlayerText.push_back(std::make_unique<Bounding>(ngl::Vec3( 0.75f,0.875f,0.0f ) , 0.2f, 0.125f, 0.1f ) ); 
  m_twoPlayerText.back()->setText("Player2");

  m_twoPlayerText.push_back(std::make_unique<Bounding>(ngl::Vec3( -0.75f,0.675f,0.0f ) , 0.1f, 0.05f, 0.1f ) ); 
  m_twoPlayerText.back()->setText("W A S D");

  m_twoPlayerText.push_back(std::make_unique<Bounding>(ngl::Vec3( 0.75f,0.675f,0.0f ) , 0.125f, 0.05f, 0.1f ) ); 
  m_twoPlayerText.back()->setText("Arrow Keys");

  m_player1Score = std::make_unique< Bounding > ( ngl::Vec3( 0.0f,0.875f,0.0f ) , 0.3f, 0.1f, 0.1f ); 
  m_player1Score->setText( "0 Score 0" );

  m_player2Score = std::make_unique< Bounding > ( ngl::Vec3( 0.75f,0.475f,0.0f ) , 0.2f, 0.1f, 0.1f ); 
  m_player2Score->setText( "Score = 0" );
  
  //General Text and m_buttons

  m_backButton = std::make_unique< Bounding > ( ngl::Vec3( 0.0f,-0.875f,0.0f ), 0.1f, 0.1f, 0.1f );
  m_backButton->setText( "Back" );


  m_scoreButton = std::make_unique< Bounding > ( ngl::Vec3( 0.0f,0.875f,0.0f ), 0.2f, 0.1f, 0.1f );
  m_scoreButton->setText( "Score = 0" ); 


  glClearColor( 0.01f, 0.01, 0.01, 1.0f );			   // Grey Background
  // enable depth testing for drawing
  glEnable(GL_DEPTH_TEST);
  // now to load the shader and set the values
  // we are creating a shader called PBR to save typos
  // in the code create some constexpr
  constexpr auto vertexShader  = "PBRVertex";
  constexpr auto fragShader    = "PBRFragment";
  // create the shader program
  ngl::ShaderLib::createShaderProgram( PBR );
  // now we are going to create empty shaders for Frag and Vert
  ngl::ShaderLib::attachShader( vertexShader, ngl::ShaderType::VERTEX );
  ngl::ShaderLib::attachShader( fragShader, ngl::ShaderType::FRAGMENT );
  // attach the source
  ngl::ShaderLib::loadShaderSource( vertexShader, "shaders/PBRVertex.glsl" );
  ngl::ShaderLib::loadShaderSource( fragShader, "shaders/PBRFragment.glsl" );
  // compile the shaders
  ngl::ShaderLib::compileShader( vertexShader );
  ngl::ShaderLib::compileShader( fragShader );
  // add them to the program
  ngl::ShaderLib::attachShaderToProgram( PBR, vertexShader );
  ngl::ShaderLib::attachShaderToProgram( PBR, fragShader );
  // now we have associated that data we can link the shader
  ngl::ShaderLib::linkProgramObject( PBR );



  //ScreenShader Linking 

  ngl::ShaderLib::loadShader( SS, "shaders/SSVertex.glsl", "shaders/SSFragment.glsl" );



  // and make it active ready to load values
  ngl::ShaderLib::use(PBR);
 // We now create our view matrix for a static camera
  ngl::Vec3 from( 2.5f, 5.0f, 0.0f );
  ngl::Vec3 to( 0.0f, 0.0f, 0.0f );
  ngl::Vec3 up( 0.0f, 1.0f, 0.0f );
  // now load to our new camera
  m_view=ngl::lookAt(from,to,up);
  ngl::ShaderLib::setUniform( "camPos", from );
  // setup the default shader material and light porerties
  // these are "uniform" so will retain their values
  ngl::ShaderLib::setUniform("lightPosition",0.0f,2.0f,2.0f);
  ngl::ShaderLib::setUniform("lightColor",400.0f,400.0f,400.0f);
  ngl::ShaderLib::setUniform("exposure",2.2f);
  ngl::ShaderLib::setUniform("albedo",0.950f, 0.71f, 0.29f);

  ngl::ShaderLib::setUniform("metallic",1.02f);
  ngl::ShaderLib::setUniform("roughness",0.38f);
  ngl::ShaderLib::setUniform("ao",0.2f);

  ngl::VAOPrimitives::createTrianglePlane("floor",20,20,1,1,ngl::Vec3::up());

  ngl::VAOPrimitives::createSphere("sphere", 1.0f, 8);

}

NGLDraw::~NGLDraw()
{

  std::cout<<"Shutting down NGL, removing VAO's and Shaders\n";

}

void NGLDraw::resize(int _w, int _h)
{

  glViewport(0,0, _w  , _h );
  m_project=ngl::perspective( 45.0f, static_cast<float>( _w ) / _h, 0.1f, 200.0f );
  m_width=_w;
  m_height=_h;

}

void NGLDraw::draw()
{

  //std::cout<<quit<<'\n';
  glViewport( 0, 0, m_width, m_height );
  // clear the screen and depth buffer
  glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

  // grab an instance of the shader manager
  ngl::ShaderLib::use(PBR);
 
  // Rotation based on the mouse position for our global transform
  ngl::Mat4 rotX;
  ngl::Mat4 rotZ;
  // create the rotation matrices
  rotX.rotateX( m_spinXFace );
  rotZ.rotateZ( m_spinZFace );
  // multiply the rotations
  m_mouseGlobalTX = rotX * rotZ;
  // add the translations
  m_mouseGlobalTX.m_m[ 3 ][ 0 ] = m_modelPos.m_x;
  m_mouseGlobalTX.m_m[ 3 ][ 1 ] = m_modelPos.m_y;
  m_mouseGlobalTX.m_m[ 3 ][ 2 ] = m_modelPos.m_z;
  // get the VBO instance and draw the built in teapot
  // draw

  //Draw all the balls

  for (int i = 0; i < m_sphereArray.size(); i++)
  {

    m_sphereArray[i]->draw("PBR", m_mouseGlobalTX, m_view, m_project);

  }

  loadMatricesToShader();

  //Draw Maze from there Bounding Boxs

  for( int y = 0; y < m_boundingBoxs.size(); y++ )
  {

    ngl::ShaderLib::use( PBR );
    ngl::ShaderLib::setUniform( "albedo", 100.0f, 100.0f, 100.0f );
    m_boundingBoxs[y]->setDrawMode( GL_LINE );
    m_boundingBoxs[y]->draw();

  }

}

/// This functions is from
/// ModDB Wiki. (n.d.). SDL ttf:Tutorials:Fonts in OpenGL. [online] Available at: https://moddb.fandom.com/wiki/SDL_ttf:Tutorials:Fonts_in_OpenGL [Accessed 5 Jun. 2022].

// Creats a SDL surface with text on, using SDL_TFF. Then renders to an open gl texture to be displayed on screen 

void NGLDraw::TextRendering( const char *_Words, SDL_Color _Color )
{
  
  TTF_Font *font = TTF_OpenFont( "font/Retro.ttf", 50 );
  
  if( !font )
  {

    std::cout<<TTF_GetError();

  }

  SDL_Surface *Message = TTF_RenderText_Blended( font, _Words , _Color ); 

  unsigned Texture = 0;

  glGenTextures( 1, &Texture ); 
  glBindTexture( GL_TEXTURE_2D, Texture );

  glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR ); 
  glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
  glEnable( GL_BLEND );

  glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA ); 

  glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, Message->w, Message->h, 0, GL_BGRA, GL_UNSIGNED_BYTE, Message->pixels );
  TTF_CloseFont( font );
  SDL_FreeSurface( Message );

}

/// End of functions from https://moddb.fandom.com/wiki/SDL_ttf:Tutorials:Fonts_in_OpenGL

// Draws the UI for the designated game mode 

void NGLDraw::drawStartScreen()
{

  if ( m_mode == 0 )
  {

    glViewport( 0, 0, m_width, m_height );
    // clear the screen and depth buffer
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT ); 

    for ( int i = 0; i < m_buttons.size(); i++ )
    {

      glActiveTexture( GL_TEXTURE0 );
      glBindTexture( GL_TEXTURE_2D, m_textures[i] );
      m_buttons[i]->draw();

    }

    for ( int i = 0; i < m_startScreenText.size(); i++ )
    {

      TextRendering( m_startScreenText[i]->getText().c_str(), m_startScreenText[i]->getColour() );
      m_startScreenText[i]->draw();  

    }

  }
  else if ( m_mode == 2 )
  {

    for ( int i = 0; i < m_sandBoxButtons.size(); i++ )
    {

      TextRendering( m_sandBoxButtons[i]->getText().c_str(), m_sandBoxButtons[i]->getColour() );
      m_sandBoxButtons[i]->draw();

    }

    TextRendering( m_backButton->getText().c_str(), m_backButton->getColour() );
    m_backButton->draw();

  }
  else if ( m_mode == 1 )
  {

    m_scoreButton->setText( "Score = " + std::to_string( m_score ) );
    TextRendering( m_scoreButton->getText().c_str(), m_scoreButton->getColour() );
    m_scoreButton->draw(); 

    TextRendering( m_backButton->getText().c_str(), m_backButton->getColour() );
    m_backButton->draw();

  }
  else if ( m_mode == 3 )
  {

    for ( int i = 0; i < m_twoPlayerText.size(); i++ )
    {

      TextRendering( m_twoPlayerText[i]->getText().c_str(), m_twoPlayerText[i]->getColour() );
      m_twoPlayerText[i]->draw();

    }

    m_player1Score->setText( std::to_string(m_score) + "       Score       " + std::to_string( m_score2 ) );
    TextRendering( m_player1Score->getText().c_str(), m_player1Score->getColour() );
    m_player1Score->draw(); 

    TextRendering( m_backButton->getText().c_str(), m_backButton->getColour() );
    m_backButton->draw();
  }
  else
  {

    TextRendering( m_backButton->getText().c_str(), {255,255,255} );
    m_backButton->draw();

  }

}



void NGLDraw::loadMatricesToShader()
{

   struct transform
   {

     ngl::Mat4 MVP;
     ngl::Mat4 normalMatrix;
     ngl::Mat4 M;

   };

    transform t;
    t.M=m_view*m_mouseGlobalTX*m_transform.getMatrix();

    t.MVP=m_project*t.M;
    t.normalMatrix=t.M;
    t.normalMatrix.inverse().transpose();
    ngl::ShaderLib::setUniformBuffer( "TransformUBO", sizeof(transform), &t.MVP.m_00 );

}

// Rotates camera and add ball movement 

void NGLDraw::RotateCameraPosX()
{

  if( m_spinXFace < 45 )
  {
    
    m_spinXFace += (float) 5.0f * m_increment;
    m_ballMovementX += 0.01 * m_increment;
    this->draw();

  }

}

// Rotates camera and add ball movement 

void NGLDraw::RotateCameraNegX()
{

  if( m_spinXFace > -45 )
  {

    m_spinXFace -= (float) 0.5f * 10.0f * m_increment;
    m_ballMovementX -= 0.01 * m_increment;
    this->draw();

  }

}

// Rotates camera and add ball movement 

void NGLDraw::RotateCameraPosZ()
{

  if( m_spinZFace < 45 )
  {

    m_spinZFace += (float) 0.5f * 10.0f * m_increment;
    m_ballMovementZ -= 0.01 * m_increment;
    this->draw();

  }

}

// Rotates camera and add ball movement 

void NGLDraw::RotateCameraNegZ()
{

  if( m_spinZFace > -45 )
  {

    m_spinZFace -= (float) 0.5f * 10.0f * m_increment;
    m_ballMovementZ += 0.01 * m_increment;
    this->draw();

  }

}

//Checks if mouse click lies in bounding box of the buttons for the current game mode
//Then executes a diffrent set of operations

int NGLDraw::mousePressEvent ( const SDL_MouseButtonEvent &_event )
{

  if( m_mode == 0 )
  {

    for ( int i = 0; i < m_buttons.size(); i++ )
    {

      if( _event.x > ( m_buttons[i]->getMinX() * ( m_width  / 2.0f ) + ( m_width  / 2.0f ) ) 
      && _event.x < ( m_buttons[i]->getMaxX() * ( m_width  / 2.0f ) + ( m_width  / 2.0f ) ) 
      && _event.y > ( m_buttons[i]->getMinY() * ( m_height / 2.0f ) + ( m_height / 2.0f ) )
      && _event.y < ( m_buttons[i]->getMaxY() * ( m_height / 2.0f ) + ( m_height / 2.0f ) ) )
      {

        return i+1;

      }

    }  

  }
  else if( m_mode == 2 )
  {

    for ( int i = 0; i < m_sandBoxButtons.size(); i++ )
    {

      if( _event.x > ( m_sandBoxButtons[i]->getMinX() * ( m_width  / 2.0f ) + ( m_width  / 2.0f ) ) 
      && _event.x < ( m_sandBoxButtons[i]->getMaxX() * ( m_width  / 2.0f ) + ( m_width  / 2.0f ) ) 
      && _event.y > ( m_sandBoxButtons[i]->getMinY() * ( m_height / 2.0f ) + ( m_height / 2.0f ) )
      && _event.y < ( m_sandBoxButtons[i]->getMaxY() * ( m_height / 2.0f ) + ( m_height / 2.0f ) ) )
      { 

        switch (i) 
        {
          case 0:
          {
            if( m_mazeWidth < 20 )
            {
              
              m_mazeWidth += 2;
              m_mazeHeight += 2;
              m_modelPos.m_x -= 1.5;
              m_modelPos.m_y -= 3;  
                
            }
            break;
          }

          case 1:
          {
            if ( m_mazeWidth > 3 )
            {

              m_mazeWidth -= 2;
              m_mazeHeight -= 2;
              m_modelPos.m_x += 1.5;
              m_modelPos.m_y += 3;  

            } 
            break;
          }

          case 2:
          {
            if ( m_sphereArray.size() > m_numberOfPlayers+1 )
            {

              m_sphereArray.pop_back();

            }
            break;
          }

          case 3:
          {
            if( m_sphereArray.size() < (m_mazeWidth*m_mazeHeight)/2 )
            {

              m_sphereArray.push_back( std::make_unique< Sphere > ( ngl::Vec3( std::rand() % m_mazeWidth - m_mazeWidth/2 ,0, std::rand() % m_mazeHeight - m_mazeHeight/2 ),  ngl::Vec3(0,0,0),	GLfloat(0.3f), ngl::Vec3(0,0,0), 2, ngl::Vec3(1.0f, 0.0f, 0.0f) ) ) ;
            
              bool place = true;

              while ( place )
              {

                m_sphereArray.back()->set( ngl::Vec3( std::rand() % m_mazeWidth - m_mazeWidth/2 ,0, std::rand() % m_mazeHeight - m_mazeHeight/2 ),  ngl::Vec3(0,0,0),	GLfloat(0.3f), ngl::Vec3(0,0,0) );
                
                for ( int i = 0; i < m_sphereArray.size(); i++ )
                {

                  if ( i != m_sphereArray.size()-1 )
                  {

                    if ( m_sphereArray[i]->getPos().m_x != m_sphereArray.back()->getPos().m_x && m_sphereArray[i]->getPos().m_z != m_sphereArray.back()->getPos().m_z )
                    {

                      continue;
                      
                    }
                    place = false; 

                  } 

                } 

              }

            }
            break;
          }
          default:
            continue;
            break;

        }
        Restart();

      }

    } 

  }
  if( _event.x > ( m_backButton->getMinX() * ( m_width  / 2.0f ) + ( m_width  / 2.0f ) ) 
  && _event.x < ( m_backButton->getMaxX() * ( m_width  / 2.0f ) + ( m_width  / 2.0f ) ) 
  && _event.y > ( m_backButton->getMinY() * ( m_height / 2.0f ) + ( m_height / 2.0f ) )
  && _event.y < ( m_backButton->getMaxY() * ( m_height / 2.0f ) + ( m_height / 2.0f ) ) )
  { 

    return -1;

  }   

  return 0;

}

void NGLDraw::AssignMaze( Board _mazeInput )
{

  m_maze = _mazeInput;

}

//Moves the ball. However first checks for collisions in x then y for the future location. 
//If a collision is detected doesnt move the ball to the x or y corrdinates

void NGLDraw::MoveBall()
{

  int count = 0;
  int coun1 = 0;

  for ( int i = 0; i < m_sphereArray.size(); i++ )
  {

    if( m_sphereArray[i]->getSphereType() != 1 )
    {

      m_sphereArray[i]->setDirection( ngl::Vec3 ( m_ballMovementZ, 0, 0 ) );
      m_sphereArray[i]->move();

      if( BBoxCollision() || SphereCollision() )
      {

        m_sphereArray[i]->set( m_sphereArray[i]->getLastPos(), m_sphereArray[i]->getDirection(), m_sphereArray[i]->getRadius(), m_sphereArray[i]->getLastRot() );

      }

      if( m_sphereArray[i]->getLastRot().m_z == m_sphereArray[i]->getRot().m_z )
      {

        count ++;

      }

      m_sphereArray[i]->setDirection( ngl::Vec3 (0, 0, m_ballMovementX) );
      m_sphereArray[i]->move();

      if( BBoxCollision() || SphereCollision() )
      {

        m_sphereArray[i]->set( m_sphereArray[i]->getLastPos(), m_sphereArray[i]->getDirection(), m_sphereArray[i]->getRadius(), m_sphereArray[i]->getLastRot() );

      }

      if( m_sphereArray[i]->getLastRot().m_x == m_sphereArray[i]->getRot().m_x )
      {

        count ++;

      }

      CollisionCheck();

    }

  }

  if ( count == (m_sphereArray.size()-1)*2 && m_mode == 3 )
  {

    //Changes collor of the Player balls in 2 person mode.
    //Only happens once it detences both balls have come to a stop

    if ( m_isSwapPlayer == false )
    {

      m_isPlayer1 = false;
      m_sphereArray[0]->setColour( ngl::Vec3(0.9f, 0.1f, 0.1f) );
      m_twoPlayerText[0]->setColour( {250,50,50} );
      m_twoPlayerText[2]->setColour( {250,50,50} );
      m_sphereArray[1]->setColour( ngl::Vec3(0.1f, 0.9f, 0.1f) );
      m_twoPlayerText[1]->setColour( {50,250,50} );
      m_twoPlayerText[3]->setColour( {50,250,50} );

    }
    else if ( m_isSwapPlayer == true )
    {

      m_isPlayer1 = true;
      m_sphereArray[0]->setColour( ngl::Vec3(0.1f, 0.95f, 0.1f) );
      m_twoPlayerText[0]->setColour( {50,250,50} );
      m_twoPlayerText[2]->setColour( {50,250,50} );
      m_sphereArray[1]->setColour( ngl::Vec3(0.95f, 0.1f, 0.1f) );
      m_twoPlayerText[1]->setColour( {250,50,50} );
      m_twoPlayerText[3]->setColour( {250,50,50} );

    }

  }

}

/// Functions inspired from 
///MDN Web Docs. (n.d.). 3D collision detection. [online] Available at: https://developer.mozilla.org/en-US/docs/Games/Techniques/3D_collision_detection.

//This functions limits the balls location to the min,max values of the collision box. ie the cloest corrdinates on the box to the ball
//Then calcuates the distence from that point to the ball. if smaller then the radius then the balls hit

bool NGLDraw::BBoxCollision()
{

  for( int y = 0; y < m_boundingBoxs.size(); y++ )
  {

    for ( int x = 0; x < m_sphereArray.size(); x++ )
    {

      float Minx = ( m_boundingBoxs[y]->center().m_x - ( m_boundingBoxs[y]->width() / 2.0f ) ); 
      float Maxx = ( m_boundingBoxs[y]->center().m_x + ( m_boundingBoxs[y]->width() / 2.0f ) ); 

      float Minz = ( m_boundingBoxs[y]->center().m_z - ( m_boundingBoxs[y]->depth() / 2.0f ) ); 
      float Maxz = ( m_boundingBoxs[y]->center().m_z + ( m_boundingBoxs[y]->depth() / 2.0f ) );

      float _x = std::clamp( m_sphereArray[x]->getPos().m_x, Minx, Maxx );
      float _z = std::clamp( m_sphereArray[x]->getPos().m_z, Minz, Maxz );

      float distence = std::sqrt( std::abs( ( _x - m_sphereArray[x]->getPos().m_x) ) + std::abs( ( _z - m_sphereArray[x]->getPos().m_z) ) );

      if( distence < m_sphereArray[0]->getRadius() + 0.2f )
      {

        return true;

      }

    }

  }
  return false;
}

//Function ends

//This functions returns a boolean based on if the ball has collided with another ball. 
//This is used to stop the balls movement if collision with anther ball

bool NGLDraw::SphereCollision()
{

  for ( int i = 0; i < m_sphereArray.size(); i++ )
  {

    for ( int x = 0; x < m_sphereArray.size(); x++ )
    {

      if( i != x )
      {

        float distence = std::sqrt( std::abs( ( m_sphereArray[i]->getPos().m_x - m_sphereArray[x]->getPos().m_x) ) + std::abs( ( m_sphereArray[i]->getPos().m_z - m_sphereArray[x]->getPos().m_z) ) );

        if ( distence < m_sphereArray[i]->getRadius() + m_sphereArray[x]->getRadius() + 0.15f ) 
        {
          
          return true;

        } 

      }

    } 

  }

  return false;

}

//This function based on the collision object executes a series of comands.
//Either continng to next level, exiting the level etc

void NGLDraw::CollisionCheck()
{

  for ( int i = m_numberOfPlayers; i < m_sphereArray.size(); i++ )
  {

    for ( int x = 0; x < m_numberOfPlayers; x++ )
    {

      float distence = std::sqrt( std::abs( ( m_sphereArray[x]->getPos().m_x - m_sphereArray[i]->getPos().m_x) ) + std::abs( ( m_sphereArray[x]->getPos().m_z - m_sphereArray[i]->getPos().m_z) ) );

      if( distence < m_sphereArray[i]->getRadius() + m_sphereArray[x]->getRadius() + 0.2f )
      {

        if ( m_sphereArray[i]->getSphereType() == 1) 
        {

          if( m_mode == 3 )
          {

            if ( x == 0 )
            {

              m_score++;

            }
            else if( x == 1 )
            {

              m_score2 ++; 

            }

          }
          Restart();

        }
        else if ( m_sphereArray[i]->getSphereType() == 2 )
        {

          if ( m_mode == 2 )
          {

            Restart();

          }
          else
          {

            CleanRestart();

          }

        }
        break;

      } 

    }

  } 

}

//This functions Restarts the level regenerating all of the scene objects ie the maze, the exit location etc 

void NGLDraw::Restart()
{  

  if( m_mode == 1 )
  {

    m_score ++;

    if( m_loop < 3 )
    {

      if ( m_mazeWidth > 8 )
      {

        m_loop ++;

        m_sphereArray.push_back( std::make_unique< Sphere > ( ngl::Vec3( std::rand() % m_mazeWidth - m_mazeWidth/2 ,0, std::rand() % m_mazeHeight - m_mazeHeight/2 ),  ngl::Vec3(0,0,0),	GLfloat(0.3f), ngl::Vec3(0,0,0), 2, ngl::Vec3(1.0f, 0.0f, 0.0f) ) ) ;
        
        bool place = true;
        
        while ( place )
        {

          m_sphereArray.back()->set( ngl::Vec3( std::rand() % m_mazeWidth - m_mazeWidth/2 ,0, std::rand() % m_mazeHeight - m_mazeHeight/2 ),  ngl::Vec3(0,0,0),	GLfloat(0.3f), ngl::Vec3(0,0,0) );
          
          for ( int i = 0; i < m_sphereArray.size(); i++ )
          {

            if ( i != m_sphereArray.size()-1 )
            {

              if ( m_sphereArray[i]->getPos() != m_sphereArray.back()->getPos() )
              {

                continue;

              }
              place = false; 

            } 

          } 

        }

      }
      else
      {

        m_mazeWidth += 2;
        m_mazeHeight += 2;
        m_modelPos.m_x -= 1.5;
        m_modelPos.m_y -= 3;

      }

    }
    else
    {

      if (m_mazeWidth > 5)
      {

        m_mazeWidth -= 2;
        m_mazeHeight -=2;
        m_modelPos.m_x += 1.5;
        m_modelPos.m_y += 3;

      }

    }

  }
  else if( m_mode == 2 )
  {

  }
  else
  {

    m_mazeWidth += 2;
    m_mazeHeight += 2;
    m_modelPos.m_x -= 1.5;
    m_modelPos.m_y -= 3;

  }

  if( m_mode == 3 )
  {

    m_sphereArray[0]->set( ngl::Vec3(m_mazeWidth/2,0,m_mazeHeight/2),  ngl::Vec3(0,0,0),	GLfloat(0.3f), ngl::Vec3(0,0,0) );
    m_sphereArray[1]->set( ngl::Vec3(-m_mazeWidth/2,0,-m_mazeHeight/2),  ngl::Vec3(0,0,0),	GLfloat(0.3f), ngl::Vec3(0,0,0) );

    for ( int i = 3; i < m_sphereArray.size(); i++ )
    {

      m_sphereArray[i]->set( ngl::Vec3( std::rand() % m_mazeWidth - m_mazeWidth/2 ,0, std::rand() % m_mazeHeight - m_mazeHeight/2 ),  ngl::Vec3(0,0,0),	GLfloat(0.2f), ngl::Vec3(0,0,0) );

    }

  }
  else
  {

    m_sphereArray[0]->set( ngl::Vec3(0,0,0),  ngl::Vec3(0,0,0),	GLfloat(0.3f), ngl::Vec3(0,0,0) );

    for ( int i = 1; i < m_sphereArray.size(); i++ )
    {

      bool place = true;
      
      while (place)
      {

        m_sphereArray[i]->set( ngl::Vec3( std::rand() % m_mazeWidth - m_mazeWidth/2 ,0, std::rand() % m_mazeHeight - m_mazeHeight/2 ),  ngl::Vec3(0,0,0),	GLfloat(0.2f), ngl::Vec3(0,0,0) );
        
        for ( int x = 0; x < m_sphereArray.size(); x++ )
        {

          if (x != i)
          {

            if (m_sphereArray[i]->getPos().m_x == m_sphereArray[x]->getPos().m_x && m_sphereArray[i]->getPos().m_z == m_sphereArray[x]->getPos().m_z)
            {

              place = true;
              break;

            }

            place = false; 

          } 

        } 

      }

    }

  }

  Board Maze( m_mazeWidth, m_mazeHeight );

  Vec2 StartingIndex( 0, 0 );

  Maze.Generate( StartingIndex );

  m_rotate = false;
  // mouse rotation values set to 0
  m_spinXFace = 0;
  m_spinZFace = 0;
  m_ballMovementX = 0.0f;
  m_ballMovementZ = 0.0f;

  m_boundingBoxs.clear();

  for ( int y = 0; y < Maze.GetHeight(); y++ )
  {

    for ( int x = 0; x < Maze.GetWidth(); x++ )
    {

      Vec2 Index( x, y );
      for ( char Border : Maze.GetCell( Index )->GetDiretions() ) 
      {

        float width = 0.0f;
        float depth = 0.0f;
        m_transform.reset();
        if (Border == 'N')
        {

            m_transform.setPosition( 0.0f, 0.0f, 0.5f );
            width = 1.0f;
            depth = 0.1f;

        }
        else if ( Border == 'E' )
        {

            m_transform.setPosition( 0.5f, 0.0f, 0.0f );
            width = 0.1f;
            depth = 1.0f;

        }
        else if ( Border == 'S' )
        {

            m_transform.setPosition( 0.0f, 0.0f, -0.5f );
            width = 1.0f;
            depth = 0.1f;

        }
        else if ( Border == 'W' ) 
        {  

            m_transform.setPosition( -0.5f, 0.0f, 0.0f );        
            width = 0.1f;
            depth = 1.0f;

        }

        m_transform.addPosition( Index.m_x - ( Maze.GetWidth() / 2 ) + 0.5f , 0.0f, Index.m_y - (Maze.GetHeight() / 2) + 0.5f );

        m_boundingBoxs.push_back( std::make_unique< ngl::BBox > ( m_transform.getPosition(), width, 1.0f, depth ) );

        m_transform.reset();
        
      }

    }

  }

}

//This does a similar thing to the function above howver it regenerates the scene object to there defult values.
//This is called at the start of each game mode loop 

void NGLDraw::CleanRestart()
{

  m_score = 0;
  m_score2 = 0;

  m_modelPos.m_x = 0;
  m_modelPos.m_y = 0;
  m_mazeWidth = 3;

  m_mazeHeight = 3;

  m_loop = 0;

  Board Maze( m_mazeWidth, m_mazeHeight );

  Vec2 StartingIndex( 0, 0 );

  Maze.Generate( StartingIndex );

  m_rotate = false;
  // mouse rotation values set to 0
  m_spinXFace = 0;
  m_spinZFace = 0;
  m_ballMovementX = 0.0f;
  m_ballMovementZ = 0.0f;

  m_sphereArray.clear();

  if( m_mode == 3 )
  {

    m_sphereArray.push_back( std::make_unique< Sphere > ( ngl::Vec3(m_mazeWidth / 2, 0, m_mazeHeight / 2),  ngl::Vec3(0,0,0),	GLfloat(0.3f), ngl::Vec3(0,0,0), 0, ngl::Vec3(0.1f, 0.95f, 0.1f) ) );
    m_sphereArray.push_back( std::make_unique< Sphere > ( ngl::Vec3(-m_mazeWidth / 2, 0, -m_mazeHeight / 2),  ngl::Vec3(0,0,0),	GLfloat(0.3f), ngl::Vec3(0,0,0), 0, ngl::Vec3(0.95f, 0.1f, 0.1f) ) );
    m_numberOfPlayers = 2;

  }
  else
  {

    m_sphereArray.push_back( std::make_unique< Sphere > ( ngl::Vec3(0,0,0),  ngl::Vec3(0,0,0),	GLfloat(0.3f), ngl::Vec3(0,0,0), 0, ngl::Vec3(0.1f, 0.95f, 0.1f) ) );
    m_numberOfPlayers = 1;

  }

  if( m_mode == 3 )
  {

    m_sphereArray.push_back( std::make_unique< Sphere > ( ngl::Vec3(0,0,0),  ngl::Vec3(0,0,0),	GLfloat(0.2f), ngl::Vec3(0,0,0), 1, ngl::Vec3(1.0f, 0.8f, 0.2f) ) );

  }
  else
  {

    m_sphereArray.push_back( std::make_unique< Sphere > ( ngl::Vec3( std::rand() % m_mazeWidth - m_mazeWidth/2 ,0, std::rand() % m_mazeHeight - m_mazeHeight/2 ),  ngl::Vec3(0,0,0),	GLfloat(0.2f), ngl::Vec3(0,0,0), 1, ngl::Vec3(1.0f, 0.8f, 0.2f) ) ); 
    if( m_sphereArray[1]->getPos() == ngl::Vec3(0.0f, 0.0f, 0.0f) )
    {

      m_sphereArray[1]->set( ngl::Vec3( m_sphereArray[1]->getPos().m_x + 1, 0, m_sphereArray[1]->getPos().m_y + 1),  ngl::Vec3(0,0,0),	GLfloat(0.2f), ngl::Vec3(0,0,0) );

    } 

  } 

  m_boundingBoxs.clear();

  for ( int y = 0; y < Maze.GetHeight(); y++ )
  {

    for ( int x = 0; x < Maze.GetWidth(); x++ )
    {
      
      Vec2 Index( x, y );
      for ( char Border : Maze.GetCell(Index)->GetDiretions() ) 
      {

        float width = 0.0f;
        float depth = 0.0f;
        m_transform.reset();
        if ( Border == 'N' )
        {

            m_transform.setPosition( 0.0f,0.0f,0.5f );
            width = 1.0f;
            depth = 0.1f;

        }
        else if ( Border == 'E' )
        {

            m_transform.setPosition( 0.5f,0.0f,0.0f );
            width = 0.1f;
            depth = 1.0f;

        }
        else if ( Border == 'S' )
        {

            m_transform.setPosition( 0.0f,0.0f,-0.5f );
            width = 1.0f;
            depth = 0.1f;

        }
        else if ( Border == 'W' ) 
        { 

            m_transform.setPosition( -0.5f,0.0f,0.0f );        
            width = 0.1f;
            depth = 1.0f;

        }

        m_transform.addPosition( Index.m_x-(Maze.GetWidth() / 2 ) + 0.5f ,0.0f,Index.m_y - (Maze.GetHeight() / 2) + 0.5f );

        m_boundingBoxs.push_back( std::make_unique< ngl::BBox > ( m_transform.getPosition(), width, 1.0f, depth ) );

        m_transform.reset();
        
      }

    }

  }

}