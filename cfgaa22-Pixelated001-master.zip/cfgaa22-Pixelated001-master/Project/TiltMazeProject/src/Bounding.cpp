#include "Bounding.h"
#include <ngl/Transformation.h>
#include <ngl/ShaderLib.h>
#include <ngl/VAOPrimitives.h>

Bounding::Bounding( ngl::Vec3 _Center, float _Width, float _Height, float _Depth )
{

  m_Center = _Center;
  m_Width = _Width; 
  m_Height = _Height;
  m_Depth = _Depth; 

  m_MinX = ( _Center.m_x - ( _Width ) );
  m_MaxX = ( _Center.m_x + ( _Width ) );

  m_MinY = ( -_Center.m_y - ( _Height ) );
  m_MaxY = ( -_Center.m_y + ( _Height ) );

  m_MinZ = ( _Center.m_z - ( _Depth / 2.0f ) );
  m_MaxZ = ( _Center.m_z + ( _Depth / 2.0f ) );

  m_colour = {225, 225, 225};
  m_Rotation = 0.0f;

}

//This uses my ScreenShader to draw the buttons directly to the screen.
//This allows me to keep the buttons on the screen with out needed to mirror the cameras transformations

void Bounding::draw() const
{  

  ngl::Transformation m_transform;
  m_transform.setScale ( m_Width, 0.0f, m_Height ); 
  m_transform.setPosition( m_Center );
  m_transform.setRotation( 90.0f, m_Rotation, m_Rotation );

  ngl::ShaderLib::use( "SS" );
  ngl::ShaderLib::setUniform( "TransformUBO", m_transform.getMatrix() );

  ngl::VAOPrimitives::draw( "floor" );

}