#ifdef WIN32
    #define SDL_MAIN_HANDLED
#endif
#include <SDL2/SDL.h>
#include <cstdlib>
#include <iostream>
#include "Board.h"
#include "NGLDraw.h"
#include <ngl/NGLInit.h>

/// @brief function to quit SDL with error message
/// @param[in] _msg the error message to send
void SDLErrorExit(const std::string &_msg);

/// @brief initialize SDL OpenGL context
SDL_GLContext createOpenGLContext( SDL_Window *window);

void StartScreenLoop(SDL_Event _event, NGLDraw* _ngl, SDL_Window *_window, SDL_Rect _rect);

void GameLoop(SDL_Event _event, NGLDraw* _ngl, SDL_Window *_window, SDL_Rect _rect);

void DungeonLoop(SDL_Event _event, NGLDraw* _ngl, SDL_Window *_window, SDL_Rect _rect);

void SandBoxLoop(SDL_Event _event, NGLDraw* _ngl, SDL_Window *_window, SDL_Rect _rect);

void TwoPlayerLoop(SDL_Event _event, NGLDraw* _ngl, SDL_Window *_window, SDL_Rect _rect);


Uint32 callback( Uint32 interval, void* param );


int main(int argc, char * argv[])
{
  
  // under windows we must use main with argc / v so jus flag unused for params
  NGL_UNUSED(argc);
  NGL_UNUSED(argv);
  // Initialize SDL's Video subsystem
  if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) < 0 )
  {
    // Or die on error
    SDLErrorExit("Unable to initialize SDL");

  }
  // now get the size of the display and create a window we need to init the video
  SDL_Rect rect;
  SDL_GetDisplayBounds(0,&rect);
  // now create our window
  SDL_Window *window=SDL_CreateWindow("SDLNGL",
                                      SDL_WINDOWPOS_CENTERED,
                                      SDL_WINDOWPOS_CENTERED,
                                      rect.w/2,
                                      rect.h/2,
                                      SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI
                                     );
  // check to see if that worked or exit
  if (!window)
  {

    SDLErrorExit("Unable to create window");

  }

  // Create our opengl context and attach it to our window

   SDL_GLContext glContext=createOpenGLContext(window);
   if(!glContext)
   {

     SDLErrorExit("Problem creating OpenGL context ");

   }
   // make this our current GL context (we can have more than one window but in this case not)
   SDL_GL_MakeCurrent(window, glContext);
  /* This makes our buffer swap syncronized with the monitor's vertical refresh */
  SDL_GL_SetSwapInterval(1);
  // we need to initialise the NGL lib which will load all of the OpenGL functions, this must
  // be done once we have a valid GL context but before we call any GL commands. If we dont do
  // this everything will crash
  ngl::NGLInit::initialize();
  // now clear the screen and swap whilst NGL inits (which may take time)
  glClear(GL_COLOR_BUFFER_BIT);
  SDL_GL_SwapWindow(window);
  // flag to indicate if we need to exit
  bool quit=false;
  // sdl event processing data structure
  SDL_Event event;
  // now we create an instance of our ngl class, this will init NGL and setup basic
  // opengl stuff ext. When this falls out of scope the dtor will be called and cleanup
  // our gl stuff
  NGLDraw ngl;

  StartScreenLoop(event, &ngl, window, rect);

  // now tidy up and exit SDL
 SDL_Quit();
 // whilst this code will never execute under windows we need to have a return from
 // SDL_Main!
 return EXIT_SUCCESS;

}


SDL_GLContext createOpenGLContext(SDL_Window *window)
{
    // Note you may have to change this depending upon the driver (Windows is fussy)
    // stick to 4.5 as the core base level for NGL works ok
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 4);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 1);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);

  // set multi sampling else we get really bad graphics that alias
  SDL_GL_SetAttribute(SDL_GL_MULTISAMPLEBUFFERS, 1);
  SDL_GL_SetAttribute(SDL_GL_MULTISAMPLESAMPLES,4);
  // Turn on double buffering with a 24bit Z buffer.
  // You may need to change this to 16 or 32 for your system
  // on mac up to 32 will work but under linux centos build only 16
  SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);
  // enable double buffering (should be on by default)
  SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
  //
  return SDL_GL_CreateContext(window);

}

void SDLErrorExit(const std::string &_msg)
{

  std::cerr<<_msg<<"\n";
  std::cerr<<SDL_GetError()<<"\n";
  SDL_Quit();
  exit(EXIT_FAILURE);

}

//The game loop for my Start screen. I define the game mode and specifiy wich inputs i want to check for

void StartScreenLoop( SDL_Event _event, NGLDraw* _ngl, SDL_Window *_window, SDL_Rect _rect )
{

  bool m_isQuit = false;
  _ngl->setmode(0);

  while(!m_isQuit)
  {

    while ( SDL_PollEvent(&_event) )
    {

      switch ( _event.type )
      {

        case SDL_QUIT : m_isQuit = true; break;

        case SDL_MOUSEBUTTONDOWN : 
        {
          if( _ngl->mousePressEvent(_event.button) == 1 )
          {

            DungeonLoop(_event, _ngl, _window, _rect);
            m_isQuit = true;

          }
          else if (_ngl->mousePressEvent(_event.button) == 2)
          {

            SandBoxLoop(_event, _ngl, _window, _rect);
            m_isQuit = true;

          }
          else if (_ngl->mousePressEvent(_event.button) == 3)
          {

            TwoPlayerLoop(_event, _ngl, _window, _rect);
            m_isQuit=true;

          }          
          break;
        }

        case SDL_WINDOWEVENT :
          int w,h;
          SDL_GetWindowSize(_window,&w,&h);
          #ifdef __APPLE__
            ngl.resize(w*2,h*2);
          #else
            _ngl->resize(w,h);
          #endif
        break;

        case SDL_KEYDOWN:
        {

          switch( _event.key.keysym.sym )
          {

            case SDLK_ESCAPE :  m_isQuit = true; break;
            case SDLK_f :
            SDL_SetWindowFullscreen(_window,SDL_TRUE);
            glViewport(0,0,_rect.w*2,_rect.h*2);
            break;

            case SDLK_g : SDL_SetWindowFullscreen(_window,SDL_FALSE); break;
            default : break;

          }

        }
        break;
      default : break;

      } 

    }

    _ngl->drawStartScreen();

    SDL_GL_SwapWindow(_window);

    SDL_UpdateWindowSurface(_window);

  }

  m_isQuit = false;

}

//The game loop for my Dungeon Game mode. I check for inputs from WASD to move the maze.

void DungeonLoop(SDL_Event _event, NGLDraw* _ngl, SDL_Window *_window, SDL_Rect _rect)
{

  bool m_isQuit=false;
  _ngl->setmode(1);
  _ngl->CleanRestart();

  while(!m_isQuit) 
  {

    while ( SDL_PollEvent(&_event) )
    {

      switch (_event.type)
      {

        case SDL_QUIT : m_isQuit = true; break;
        case SDL_MOUSEBUTTONDOWN :
        {
          if(_ngl->mousePressEvent(_event.button) == -1)
          {

            StartScreenLoop(_event, _ngl, _window, _rect);
            m_isQuit = true;

          } 
          break;
        }

        case SDL_WINDOWEVENT :
          int w,h;
          SDL_GetWindowSize(_window,&w,&h);
          #ifdef __APPLE__
            ngl.resize(w*2,h*2);
          #else
            _ngl->resize(w,h);
          #endif
        break;

        case SDL_KEYDOWN:
        {

          switch( _event.key.keysym.sym )
          {

            case SDLK_ESCAPE :  m_isQuit = true; break;
            case SDLK_d : _ngl->RotateCameraNegX(); break;
            case SDLK_a : _ngl->RotateCameraPosX(); break;
            case SDLK_w : _ngl->RotateCameraPosZ(); break;
            case SDLK_s : _ngl->RotateCameraNegZ(); break;
            case SDLK_f :
            SDL_SetWindowFullscreen(_window,SDL_TRUE);
            glViewport(0,0,_rect.w*2,_rect.h*2);
            break;

            case SDLK_g : SDL_SetWindowFullscreen(_window,SDL_FALSE); break;
            default : break;

          }

        }

        break;
      default : break;

      } 

    } 

    _ngl->MoveBall();
    _ngl->BBoxCollision();

    _ngl->draw();
    _ngl->drawStartScreen();

    SDL_GL_SwapWindow(_window);

    SDL_UpdateWindowSurface(_window);

  }

  m_isQuit = false;

}

//Sandbox Game mode loop

void SandBoxLoop(SDL_Event _event, NGLDraw* _ngl, SDL_Window *_window, SDL_Rect _rect)
{

  bool m_isQuit=false;
  _ngl->setmode(2); 
  _ngl->CleanRestart();

  while(!m_isQuit) 
  {

    while ( SDL_PollEvent(&_event) )
    {

      switch (_event.type)
      {

        case SDL_QUIT : m_isQuit = true; break;
        case SDL_MOUSEBUTTONDOWN : 
          if(_ngl->mousePressEvent(_event.button) == -1)
          {

            StartScreenLoop(_event, _ngl, _window, _rect);
            m_isQuit = true;

          } 
          break;

        case SDL_WINDOWEVENT :
          int w,h;
          SDL_GetWindowSize(_window,&w,&h);
          #ifdef __APPLE__
            ngl.resize(w*2,h*2);
          #else
            _ngl->resize(w,h);
          #endif
        break;

        case SDL_KEYDOWN:
        {

          switch( _event.key.keysym.sym )
          {

            case SDLK_ESCAPE :  m_isQuit = true; break;
            case SDLK_d : _ngl->RotateCameraNegX(); break;
            case SDLK_a : _ngl->RotateCameraPosX(); break;
            case SDLK_w : _ngl->RotateCameraPosZ(); break;
            case SDLK_s : _ngl->RotateCameraNegZ(); break;
            case SDLK_f :
            SDL_SetWindowFullscreen(_window,SDL_TRUE);
            glViewport(0,0,_rect.w*2,_rect.h*2);
            break;

            case SDLK_g : SDL_SetWindowFullscreen(_window,SDL_FALSE); break;
            default : break;

          }

        } 

        break;
      default : break;

      } 

    }

    _ngl->MoveBall();
    _ngl->BBoxCollision();

    _ngl->draw();
    _ngl->drawStartScreen();

    SDL_GL_SwapWindow(_window);

    SDL_UpdateWindowSurface(_window);

  }

}

//Two Player Loop. I check for a diffrent series of inputs dependant on which players turn it is.
//This also counts the number of inputs limiting each player to 2 inputs.

void TwoPlayerLoop(SDL_Event _event, NGLDraw* _ngl, SDL_Window *_window, SDL_Rect _rect)
{

  bool m_isQuit=false;
  int m_singleTap = 0;
  _ngl->setmode(3);
  _ngl->setincrement(2.5f);
  _ngl->CleanRestart();

  while(!m_isQuit)
  {

    while ( SDL_PollEvent(&_event) )
    {

      switch (_event.type) 
      {

        case SDL_QUIT : m_isQuit = true; break;
        case SDL_MOUSEBUTTONDOWN : 
          if(_ngl->mousePressEvent(_event.button) == -1)
          {
            _ngl->setincrement(1.01);
            StartScreenLoop(_event, _ngl, _window, _rect);
            m_isQuit = true;

          }
          break;
        
        case SDL_WINDOWEVENT :
          int w,h;
          SDL_GetWindowSize(_window,&w,&h);
          #ifdef __APPLE__
            ngl.resize(w*2,h*2);
          #else
            _ngl->resize(w,h);
          #endif
        break;

        case SDL_KEYDOWN:
        {

          if(_ngl->getisPlayer1() == true && m_singleTap!=2)
          {

            switch( _event.key.keysym.sym )
            {

              case SDLK_ESCAPE :  m_isQuit = true; break;
              case SDLK_d : _ngl->RotateCameraNegX(); m_singleTap ++; break;
              case SDLK_a : _ngl->RotateCameraPosX(); m_singleTap ++; break;
              case SDLK_w : _ngl->RotateCameraPosZ(); m_singleTap ++; break;
              case SDLK_s : _ngl->RotateCameraNegZ(); m_singleTap ++; break;
              case SDLK_f :
              SDL_SetWindowFullscreen(_window,SDL_TRUE);
              glViewport(0,0,_rect.w*2,_rect.h*2);
              break;

              case SDLK_g : SDL_SetWindowFullscreen(_window,SDL_FALSE); break;
              default : break;

            }
            if (m_singleTap == 2)
            {

              _ngl->setisSwapPlayer(false);

            }  

          }
          else if (_ngl->getisPlayer1() == false && m_singleTap!=0 )
          {

            switch( _event.key.keysym.sym )
            {

              case SDLK_ESCAPE :  m_isQuit = true; break;
              case SDLK_RIGHT : _ngl->RotateCameraNegX(); m_singleTap --; break;
              case SDLK_LEFT : _ngl->RotateCameraPosX(); m_singleTap --; break;
              case SDLK_UP : _ngl->RotateCameraPosZ(); m_singleTap --; break;
              case SDLK_DOWN : _ngl->RotateCameraNegZ(); m_singleTap --; break;
              case SDLK_f :
              SDL_SetWindowFullscreen(_window,SDL_TRUE);
              glViewport(0,0,_rect.w*2,_rect.h*2);
              break;

              case SDLK_g : SDL_SetWindowFullscreen(_window,SDL_FALSE); break;
              default : break;

            }
            if (m_singleTap == 0)
            {

              _ngl->setisSwapPlayer(true);


            }

          } 

        }

        break;
      default : break;

      } 

    }

    _ngl->MoveBall();
    _ngl->BBoxCollision();

    _ngl->draw();

    _ngl->drawStartScreen();

    SDL_GL_SwapWindow(_window);

    SDL_UpdateWindowSurface(_window);

  }

}