#include "Cell.h"
#include <iostream>
#include <algorithm>
#include <string>
#include <random>
#include <chrono> 

char Cell::GetDirection( const int _index ) const
{

    return m_direction[_index];

}

void Cell::Check()
{
    m_isChecked = true;
}

bool Cell::GetChecked() const
{

    return m_isChecked;

}

void Cell::Remove( const char _border )
{

    std::vector< char >::iterator m_removeIndex = std::find( m_direction.begin(), m_direction.end(), _border );

    m_direction.erase( m_removeIndex );

};

void Cell::Shuffle()
{

    unsigned m_seed = std::chrono::system_clock::now().time_since_epoch().count();

    std::default_random_engine e(m_seed);

    std::shuffle(m_direction.begin(), m_direction.end(), std::default_random_engine(e));

};

std::vector< char > Cell::GetDiretions() const
{

    return m_direction;

};
