#include "Sphere.h"
#include <ngl/VAOPrimitives.h>


Sphere::Sphere( ngl::Vec3 _pos, ngl::Vec3 _dir,  GLfloat _rad, ngl::Vec3 _rot, int _SphereType, ngl::Vec3 _Colour )
{
  // set values from params
  m_lastPos = _pos;
  m_pos = _pos;
  m_dir = _dir;
  m_radius = _rad;
  m_rot = _rot;
  m_hit = false;
  m_sphereType = _SphereType;
  m_colour = _Colour;
  m_circumfrence = 2 * ngl::PI * _rad;

}

Sphere::Sphere()
{

  m_hit = false;

}

void Sphere::loadMatricesToShader( ngl::Transformation &_tx, const ngl::Mat4 &_globalMat,const  ngl::Mat4 &_view,const ngl::Mat4 &_project  ) const
{

    struct transform
    {

        ngl::Mat4 MVP;
        ngl::Mat4 normalMatrix;
        ngl::Mat4 M;

    };

    transform t;
    t.M = _view * _globalMat * _tx.getMatrix(); //_tx.getMatrix() -> Model Matrix / view matrix transforms objects in or out of eye 

    t.MVP = _project * t.M; //Project -> turn corridate range from given to -1 ,1 
    t.normalMatrix = t.M; //LightMovement
    t.normalMatrix.inverse().transpose(); //LightMovement
    ngl::ShaderLib::setUniformBuffer( "TransformUBO", sizeof( transform ), &t.MVP.m_00 );
    // ngl::ShaderLib::setUniform("albedo",0.0f, 1.0f, 0.0f);
    

}


void Sphere::draw( const std::string &_shaderName, const ngl::Mat4 &_globalMat,  const ngl::Mat4 &_view , const ngl::Mat4 &_project )const
{

  // draw wireframe if hit
  if( m_hit )
  {

    glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );

  }
  else
  {

    glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );

  }


  ngl::ShaderLib::use( _shaderName );
  ngl::ShaderLib::setUniform( "albedo", m_colour );

  // grab an instance of the primitives for drawing
  ngl::Transformation t;

  t.setPosition( m_pos );
  t.setScale( m_radius, m_radius, m_radius );
  t.setRotation( m_rot );
  loadMatricesToShader( t, _globalMat, _view, _project );
  ngl::VAOPrimitives::draw( "sphere" );
  glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );

}



void Sphere :: set( ngl::Vec3 _pos, ngl::Vec3 _dir, GLfloat _rad, ngl::Vec3 _rot )
{

  m_pos = _pos;
  m_dir = _dir;
  m_radius = _rad;
  m_rot = _rot;

}

void Sphere::move()
{

  m_lastrot = m_rot;
  // store the last position
  m_lastPos = m_pos;
  // update the current position
  m_pos += m_dir;

  m_rot.m_z -= ( ( m_dir.m_x / m_circumfrence ) * 360 ) ;
  m_rot.m_x += ( ( m_dir.m_z / m_circumfrence ) * 360 ) ;

  // get the next position
  m_nextPos = m_pos+m_dir;

  m_hit = false;

}



