#include <iostream>
#include "Board.h"
#include <ngl/VAOPrimitives.h>
#include <ngl/ShaderLib.h>


Board::Board( float _width, float _height )
: m_dimensions{ _width, _height }
{

    m_cells.resize( m_dimensions.m_y, std::vector< Cell >( m_dimensions.m_x ) );

}

Cell* Board::GetCell( const Vec2 _index )
{

    return &( m_cells[_index.m_y][_index.m_x] );

}

//This removes the opposite wall when creating a path way between 2 cells 

char Board::OppositeWall( const char _border ) const
{

    if( _border == 'N' )
    {

        return 'S';

    }
    else if( _border == 'S' )
    {

        return 'N';

    }
    else if( _border == 'E' )
    {

        return 'W';

    }
    else if( _border == 'W' )
    {

        return 'E';

    }
    return 0; 

};

//This calculates the next cell indec based of the direction the algorithm is checking 

Vec2 Board::NextIndexCalc( char _border, Vec2 io_index )
{

    if( _border == 'N' )
    {

        io_index.m_y = io_index.m_y + 1;
        return io_index;

    }
    else if( _border == 'E' )
    {

        io_index.m_x = io_index.m_x + 1;
        return io_index;

    }
    else if( _border == 'S' )
    {

        io_index.m_y = io_index.m_y - 1;
        return io_index;

    }
    else if( _border == 'W' )
    {

        io_index.m_x = io_index.m_x - 1;
        return io_index;

    }
    return io_index; 

};

float Board::GetWidth() const
{
    return m_dimensions.m_x;
};

float Board::GetHeight() const
{

    return m_dimensions.m_y;

};

//This function recursivily runs checking all directions remaining on a cell to see if the neighbouring cell in that direction has been checked.
//If not it creates a path way and checks that cell. 
//If all cells have been checks the algorithm loops back untill one of the preivouse cells have a neighbout not checked.

void Board::Generate( Vec2 _index )
{

    Cell* m_currentCell = GetCell( _index );

    m_currentCell->Check();

    m_currentCell->Shuffle();

    for ( char m_border : m_currentCell->GetDiretions() )
    {

        Vec2 m_nextIndex = NextIndexCalc( m_border, _index );

        Cell* m_nextCell = GetCell( m_nextIndex );

        if ( m_nextIndex.m_x >= 0 && m_nextIndex.m_x < m_dimensions.m_x 
        && m_nextIndex.m_y >= 0 && m_nextIndex.m_y < m_dimensions.m_y && m_nextCell->GetChecked() == 0 )
        {

            m_currentCell->Remove( m_border );

            m_nextCell->Remove(OppositeWall( m_border ) );

            Generate( m_nextIndex );        

        }

    }

}

struct transform
        {
            ngl::Mat4 MVP;
            ngl::Mat4 normalMatrix;
            ngl::Mat4 M;
        };
