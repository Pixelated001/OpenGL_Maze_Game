#include "Vec2.h"

Vec2::Vec2( float _x, float _y )
: m_x{_x},m_y{_y}
{
    
}